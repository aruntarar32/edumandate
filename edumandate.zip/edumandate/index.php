
<?php include 'inc/topHeader.php';?>

<header class="main-header header-style-three">

<?php include 'inc/header.php';?>

</header>
<!--End Main Header -->

	<!-- Banner Section -->
	<section class="banner-section-two">
		<div class="banner-carousel owl-carousel owl-theme">
			<!-- Slide Item -->
			<div class="slide-item active">
				<div class="bg-image" style="background-image: url(images/edumandate/gallery2.jpg);"></div>
				<div class="auto-container">
					<div class="content-box">
						<!-- <div class="number animate-2">#1</div> -->
						<h1 class="title animate-1">Explore. Learn. <br> Achieve Worldwide.</h1>
						<div class="btn-box animate-3">
							<a href="javascript:void(0);" class="theme-btn btn-style-one"><span class="btn-title">Explore now</span></a>
							<a href="javascript:void(0);" class="theme-btn btn-style-two"><span class="btn-title">Contact now</span></a>
						</div>
					</div>
				</div>
			</div>

			<!-- Slide Item -->
			<div class="slide-item">
				<div class="bg-image" style="background-image: url(images/edumandate/gallery4.jpg);"></div>
				<div class="auto-container">
					<div class="content-box">
						<!-- <div class="number animate-2">#1</div> -->
						<h1 class="title animate-1">Your Future,   <br> Global Education</h1>
						<div class="btn-box animate-3">
							<a href="javascript:void(0);" class="theme-btn btn-style-one"><span class="btn-title">Explore now</span></a>
							<a href="javascript:void(0);" class="theme-btn btn-style-two"><span class="btn-title">Contact now</span></a>
						</div>
					</div>
				</div>
			</div>
            <div class="slide-item">
				<div class="bg-image" style="background-image: url(images/edumandate/3.jpg);"></div>
				<div class="auto-container">
					<div class="content-box">
						<!-- <div class="number animate-2">#1</div> -->
						<h1 class="title animate-1">Unlock Your <br>Future Overseas</h1>
						<div class="btn-box animate-3">
							<a href="javascript:void(0);" class="theme-btn btn-style-one"><span class="btn-title">Explore now</span></a>
							<a href="javascript:void(0);" class="theme-btn btn-style-two"><span class="btn-title">Contact now</span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="bottom-box">
			<div class="auto-container">
				<div class="content">
					<div class="inner">
						<span class="icon icon-arrow-up"></span>
							<div class="images">
							<img src="images/resource/avatar-1.jpg" alt="">
							<img src="images/resource/avatar-3.jpg" alt="">
							<img src="images/resource/avatar-2.jpg" alt="">
						</div>
						<div class="text"><strong class="color2">37800</strong> satisfied students with immigro</div>
					</div>
				</div>
			</div>
		</div>
        <div class="bottom-box">
			<div class="auto-container">
				<div class="content">
					<div class="inner">
						<span class="icon icon-arrow-up"></span>
							<div class="images">
							<img src="images/resource/avatar-1.jpg" alt="">
							<img src="images/resource/avatar-3.jpg" alt="">
							<img src="images/resource/avatar-2.jpg" alt="">
						</div>
						<div class="text"><strong class="color2">37800</strong> satisfied students with immigro</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Banner Section -->


    <section class="why-choose-us-two" style=background-color:#fff;>
		<div class="bg bg-image" style="/* background-image: url(images/background/3.jpg); */"></div>
		<!-- <div class="bg bg-pattern-5"></div> -->

		<div class="auto-container">            
			<div class="row g-0">
				<!-- Title Column -->
				<div class="title-column col-xl-4 col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
						<div class="sec-title light">
							<h2>Boost your recruitment efforts</h2>
						</div>
						<a href="javascript:void(0);" class="theme-btn btn-style-four small">Read More</a>
					</div>
				</div>

				<!-- Content Column -->
				<div class="content-column col-xl-8 col-lg-12 col-ms-12 col-sm-12">
					<div class="row g-0">
						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
							<div class="inner-box">
								<i class="icon flaticon-interview"></i>
								<i class="bg-icon flaticon-interview"></i>
								<h6 class="title"><a href="javascript:void(0);">Direct Interviews</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="300ms" style="visibility: visible; animation-delay: 300ms; animation-name: fadeInUp;">
							<div class="inner-box">
								<i class="icon flaticon-low-cost"></i>
								<i class="bg-icon flaticon-low-cost"></i>
								<h6 class="title"><a href="javascript:void(0);">Cost Effective</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
							<div class="inner-box">
								<i class="icon flaticon-loyalty"></i>
								<i class="bg-icon flaticon-loyalty"></i>
								<h6 class="title"><a href="javascript:void(0);">Trusted Customers</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="300ms" style="visibility: visible; animation-delay: 300ms; animation-name: fadeInUp;">
							<div class="inner-box">
								<i class="icon flaticon-online-support"></i>
								<i class="bg-icon flaticon-online-support"></i>
								<h6 class="title"><a href="javascript:void(0);">24/7 Support</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

					</div>    
				</div>
			</div>
		</div>
	</section>

	<!-- Services Section Three -->
	<section class="services-section-three">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">What do we offer</span>
				<h2>Outstanding immigration<br> visa <span class="color3">services.</span></h2>
			</div>

			<div class="row">
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/service-3-1.jpg" alt=""></a></figure>
						</div>
						<div class="overlay-content">
							<i class="icon fa fa-graduation-cap"></i>
							<h6 class="title"><a href="javascript:void(0);">Student Visa</a></h6>
							<div class="text">There are many text of pass.</div>
						</div>
					</div>
				</div>

				<!-- Service Block Three -->
				<div class="service-block-three col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/service-3-2.jpg" alt=""></a></figure>
						</div>
						<div class="overlay-content">
							<i class="icon fa fa-briefcase"></i>
							<h6 class="title"><a href="javascript:void(0);">Business Visa</a></h6>
							<div class="text">There are many text of pass.</div>
						</div>
					</div>
				</div>

				<!-- Service Block Three -->
				<div class="service-block-three col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/service-3-3.jpg" alt=""></a></figure>
						</div>
						<div class="overlay-content">
							<i class="icon fa fa-family"></i>
							<h6 class="title"><a href="javascript:void(0);">Family Visa</a></h6>
							<div class="text">There are many text of pass.</div>
						</div>
					</div>
				</div>

				<!-- Service Block Three -->
				<div class="service-block-three col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/service-3-4.jpg" alt=""></a></figure>
						</div>
						<div class="overlay-content">
							<i class="icon fa fa-camera"></i>
							<h6 class="title"><a href="javascript:void(0);">Tourist Visa</a></h6>
							<div class="text">There are many text of pass.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Services Section-->

	<!-- Clients Section   -->
	<section class="clients-section">
		<div class="auto-container">
			<!-- Sponsors Outer -->
			<div class="sponsors-outer">
				<!--clients carousel-->
				<ul class="clients-carousel owl-carousel owl-theme">
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
					<li class="slide-item"> <a href="javascript:void(0);"><img src="images/resource/client.png" alt=""></a> </li>
				</ul>
			</div>
		</div>
	</section>
	<!--End Clients Section -->

	<!-- About Section Three -->
	<section class="about-section-three pull-down">
		<div class="bg bg-pattern-8"></div>
		<div class="auto-container">
			<div class="row">
				<div class="content-column col-xl-6 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
					<div class="inner-column">
						<div class="sec-title">
							<span class="sub-title">about the company</span>
							<h2>The market leading visa & <br>immigration <span class="color3">firm</span></h2>
							<div class="text">There are many variations of passages of Lorem Ipsum available, but the majory have suffered alteration in some form, by simply free text available in injected humour, or randomised words.</div>
						</div>

						<div class="row">
							<div class="info-box col-lg-6 col-md-6">
								<div class="inner">
									<h6 class="title"><i class="icon fa fa-circle-arrow-right"></i> Trusted Consultant</h6>
									<div class="text">Lorem ipsum dolor sit amet not is consectetur notted.</div>
								</div>
							</div>
						
							<div class="info-box col-lg-6 col-md-6">
								<div class="inner">
									<h6 class="title"><i class="icon fa fa-circle-arrow-right"></i> 100% Approval</h6>
									<div class="text">Lorem ipsum dolor sit amet not is consectetur notted.</div>
								</div>
							</div>
						</div>

						<div class="bottom-box">
							<!-- Founder Info -->
							<div class="founder-info">
								<figure class="thumb"><img src="images/resource/ceo-thumb.jpg" alt=""></figure>
								<h6 class="name">Aleesha Brown</h6>
								<span class="designation">CEO & CO Founder</span>
							</div>
							
							<a href="javascript:void(0);" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Explore More</span></a>
						</div>
					</div>
				</div>

				<!-- Image Column -->
				<div class="image-column col-xl-6 col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image-box">
							<figure class="abs-image"><img src="images/resource/image-2.png" alt=""></figure>
							<figure class="image-1 overlay-anim wow fadeInRight"><img src="images/resource/about-7.jpg" alt=""></figure>
							<figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about-8.jpg" alt=""></figure>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--Emd About Section Three -->

	<!-- Fun Fact Section -->
	<section class="fun-fact-section">
		<div class="fact-counter">
			<div class="bg bg-pattern-1"></div>
			<div class="auto-container">
				<div class="row">
					<!-- Counter block-->
					<div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
						<div class="inner">
							<div class="content">
								<i class="icon far fa-plus"></i>
								<div class="count-box"><span class="count-text" data-speed="3000" data-stop="870">0</span></div>
								<h6 class="counter-title">Visa Process</h6>
							</div>
						</div>
					</div>

					<!--Counter block-->
					<div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
						<div class="inner">
							<div class="content">
								<i class="icon far fa-plus"></i>
								<div class="count-box"><span class="count-text" data-speed="3000" data-stop="480">0</span></div>
								<h6 class="counter-title">Success Stories</h6>
							</div>
						</div>
					</div>

					<!--Counter block-->
					<div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
						<div class="inner">
							<div class="content">
								<i class="icon far fa-plus"></i>
								<div class="count-box"><span class="count-text" data-speed="3000" data-stop="620">0</span></div>
								<h6 class="counter-title">Team Members</h6>
							</div>
						</div>
					</div>

					<!--Counter block-->
					<div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
						<div class="inner">
							<div class="content">
								<i class="icon far fa-plus"></i>
								<div class="count-box"><span class="count-text" data-speed="3000" data-stop="970">0</span></div>
								<h6 class="counter-title">Happy Clients</h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Fun Fact Section -->

	<!-- Video Section -->
	<section class="video-section pull-up">
		<div class="bg bg-image" style="background-image: url(images/background/5.jpg)"></div>
		<div class="auto-container">
			<div class="content">
				<a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i><span class="ripple"></span></a>
				<h2 class="title">We counselling students <br>to get study visa</h2>
				<div class="btn-box">
					<a href="javascript:void(0);" class="theme-btn btn-style-one">Explore More</a>
					<a href="javascript:void(0);" class="theme-btn btn-style-two">Contact Now</a>
				</div>
			</div>
		</div>
	</section>
	<!--End Video Section -->

	<!-- Countries Section -->
	<section class="countries-section">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">countries you can visit</span>
				<h2>Countries we’re supporting <br>for the <span class="color3">immigration</span></h2>
			</div>
	
			<div class="carousel-outer">
				<!-- Countries Carousel -->
				<div class="countries-carousel owl-carousel owl-theme">
					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-1.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Australia</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-2.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Germany</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-3.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Brazil</a>
						</div>
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-4.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Russia</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-5.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">England</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/resource/flag-6.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">India</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--End Countries Section Two -->

	<!-- Features Section Two -->
	<section class="features-section-two">
		<div class="auto-container">
			<div class="outer-box">
				<span class="icon-plane"></span>
				<div class="row">
					<div class="title-column col-lg-6">
						<div class="inner-column">
							<div class="sec-title light">
								<span class="sub-title">check our faqs</span>
								<h2>Looking for best <br>study visa <span class="color3">country</span></h2>
							</div>
						</div>
					</div>
					<div class="features-column col-lg-6">
						<div class="inner-column">
							<ul class="list-style-two">
								<li><i class="fa fa-check-circle"></i> Visas</li>
								<li><i class="fa fa-check-circle"></i> Study Visa</li>
								<li><i class="fa fa-check-circle"></i> Country Citizenship</li>
								<li><i class="fa fa-check-circle"></i> Permanent Residence</li>
							</ul>
							<figure class="image"><img src="images/resource/image-5.png" alt=""></figure>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Features Section Two -->
	
	<!-- FAQ Section -->
	<section class="faqs-section pull-up">
		<div class="bg bg-pattern-9"></div>
		<div class="auto-container">
			<div class="row">
				<!-- Image Column -->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="image-box">
						<span class="sub-title bounce-y">100% Success Rate</span>
						<figure class="image-1"><img src="images/resource/image-3.png" alt=""></figure>
						<figure class="image-2"><img src="images/resource/image-4.jpg" alt=""></figure>
						<figure class="plane-icon"><img src="images/resource/plane-2.png" alt=""></figure>
					</div>
				</div>
				
				<!-- FAQ Column -->
				<div class="faq-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="sec-title">
							<span class="sub-title">check our faqs</span>
							<h2>People frequently asked <br>few <span class="color3">questions</span></h2>
						</div>
						
						<ul class="accordion-box wow fadeInRight">
							<!--Block-->
							<li class="accordion block">
								<div class="acc-btn">How to get free immigration?
									<div class="icon fa fa-angle-right"></div>
								</div>
								<div class="acc-content">
									<div class="content">
										<div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit.</div>
									</div>
								</div>
							</li>
							
							<!--Block-->
							<li class="accordion block active-block">
								<div class="acc-btn active">Which country is good for living?
									<div class="icon fa fa-angle-right"></div>
								</div>
								<div class="acc-content current">
									<div class="content">
										<div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit.</div>
									</div>
								</div>
							</li>

							<!--Block-->
							<li class="accordion block">
								<div class="acc-btn">Canada study visa requiements?
									<div class="icon fa fa-angle-right"></div>
								</div>
								<div class="acc-content">
									<div class="content">
										<div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit.</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--End FAQ Section -->

	<!-- Training Section Three -->
	<section class="training-section-three">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">Training & Certification</span>
				<h2>Get the Immigration <br> Trainings you <span class="color3">Deserve</span></h2>
			</div>
			
			<div class="carousel-outer">
				<div class="training-carousel-two owl-carousel owl-theme">
					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/resource/training-3-1.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Citizenship Test</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
									<h5 class="title"><a href="javascript:void(0);">Citizenship Test</a></h5>
									<div class="text">There are many variations of passages of available, but the majority have suffered freedom alteration.</div>
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/resource/training-3-2.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Take IELTS</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
									<h5 class="title"><a href="javascript:void(0);">Take IELTS</a></h5>
									<div class="text">There are many variations of passages of available, but the majority have suffered freedom alteration.</div>
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/resource/training-3-3.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">PTE Coaching</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
									<h5 class="title"><a href="javascript:void(0);">PTE Coaching</a></h5>
									<div class="text">There are many variations of passages of available, but the majority have suffered freedom alteration.</div>
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/resource/training-3-4.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">OET Coaching</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
									<h5 class="title"><a href="javascript:void(0);">OET Coaching</a></h5>
									<div class="text">There are many variations of passages of available, but the majority have suffered freedom alteration.</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Training Section -->

	<!-- Why Choose US -->
	<section class="why-choose-us-two">
		<div class="bg bg-image" style="background-image: url(images/background/3.jpg)"></div>
		<div class="bg bg-pattern-5"></div>

		<div class="auto-container">            
			<div class="row g-0">
				<!-- Title Column -->
				<div class="title-column col-xl-4 col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column wow fadeInLeft">
						<div class="sec-title light">
							<h2>You <br>should choose the only quality cosnultation</h2>
						</div>
						<a href="javascript:void(0);" class="theme-btn btn-style-four small">Read More</a>
					</div>
				</div>

				<!-- Content Column -->
				<div class="content-column col-xl-8 col-lg-12 col-ms-12 col-sm-12">
					<div class="row g-0">
						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
							<div class="inner-box">
								<i class="icon flaticon-interview"></i>
								<i class="bg-icon flaticon-interview"></i>
								<h6 class="title"><a href="javascript:void(0);">Direct Interviews</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
							<div class="inner-box">
								<i class="icon flaticon-low-cost"></i>
								<i class="bg-icon flaticon-low-cost"></i>
								<h6 class="title"><a href="javascript:void(0);">Cost Effective</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
							<div class="inner-box">
								<i class="icon flaticon-loyalty"></i>
								<i class="bg-icon flaticon-loyalty"></i>
								<h6 class="title"><a href="javascript:void(0);">Trusted Customers</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

						<!-- Features Block Three -->
						<div class="feature-block-three col-lg-6 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
							<div class="inner-box">
								<i class="icon flaticon-online-support"></i>
								<i class="bg-icon flaticon-online-support"></i>
								<h6 class="title"><a href="javascript:void(0);">24/7 Support</a></h6>
								<div class="text">There are many is variations of passages of rm Ipsum available but the majority.</div>
							</div>
						</div>

					</div>    
				</div>
			</div>
		</div>
	</section>
	<!--Emd Why Choose US -->
	 
	<!-- News Section -->
	<section class="news-section">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">News & Updates</span>
				<h2>Latest news directly <br> from the <span class="color3">blog</span></h2>
			</div>
	
			<div class="row">
				<!-- News Block -->
				<div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/news-1.jpg" alt=""></a></figure>
							<span class="date">30 <span class="month">March</span></span>
						</div>
						<div class="lower-content">
							<ul class="post-info">
								<li><i class="fa fa-user-circle"></i>Admin</li>
								<li><i class="fa fa-comments"></i> 2 Comments</li>
							</ul>
							<h4 class="title"><a href="javascript:void(0);">Top 9 most demand jobs in canada</a></h4>
							<div class="text">There are not many of passages of lorem ipsum available alteration in some form.</div>
						</div>
					</div>
				</div>


				<!-- News Block -->
				<div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/news-2.jpg" alt=""></a></figure>
							<span class="date">30 <span class="month">March</span></span>
						</div>
						<div class="lower-content">
							<ul class="post-info">
								<li><i class="fa fa-user-circle"></i>Admin</li>
								<li><i class="fa fa-comments"></i> 2 Comments</li>
							</ul>
							<h4 class="title"><a href="javascript:void(0);">Top 9 most demand jobs in canada</a></h4>
							<div class="text">There are not many of passages of lorem ipsum available alteration in some form.</div>
						</div>
					</div>
				</div>
	
				<!-- News Block -->
				<div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/resource/news-3.jpg" alt=""></a></figure>
							<span class="date">30 <span class="month">March</span></span>
						</div>
						<div class="lower-content">
							<ul class="post-info">
								<li><i class="fa fa-user-circle"></i>Admin</li>
								<li><i class="fa fa-comments"></i> 2 Comments</li>
							</ul>
							<h4 class="title"><a href="javascript:void(0);">Top 9 most demand jobs in canada</a></h4>
							<div class="text">There are not many of passages of lorem ipsum available alteration in some form.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--End News Section -->



	<?php include 'inc/footer.php';?>