


<?php include 'inc/topHeader.php';?>
<style>

	.application figure img{
		/* width: 340px; */
		height: 440px;
	}
	.application .owl-carousel .owl-item img{
		/* width: 340px; */
		/* height: 440px; */
	}

	.application .training-block-two .overlay-content .read-more {
			position: absolute;
			right: 30px;
			top: -28px;
			display: -webkit-box;
			display: -ms-flexbox;
			display: flex;
			-webkit-box-align: center;
			-ms-flex-align: center;
			align-items: center;
			-webkit-box-pack: center;
			-ms-flex-pack: center;
			justify-content: center;
			height: 52px;
			width: 100%;
			border-radius: 50px;
			padding:10px 15px;
			overflow: hidden;
			color: #ffffff;
			background-color: var(--bg-theme-color3);
			-webkit-transition: all 300ms ease;
			transition: all 300ms ease;
		}

		.application .training-block-two .overlay-content {
			position: absolute;
			/* padding-top: 30px; */
			left: 5px;
			right: 5px;
			bottom:5px;
			overflow: hidden;
			z-index: 3;
			}

		.feature-block-two .overlay-content::before{
			background-color: #004183;
		}

		.feature-block-two .overlay-content .text{
			color:#fff;
		}
		.feature-block-two .inner-box{
			border-radius:1rem;
			border:1px solid #0000004f;
		}
		.feature-block-two .image img{
			border-radius:1rem;
		}
		.feature-block-two .overlay-content::before{
			border-radius: 1rem;
		}
		.feature-block-two .overlay-content .icon{
			color:#fff;
		}

		.europe .team-block .inner-box {
			position: relative;
			padding: 15px;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
			border: 1px solid #e3000f;
			border-radius: 10px;
		}

		.mixCountry .country-block .flag {
			position: relative;
			display: block;
			height: 100%;
			width: 100%;
			border-radius: 0%;
			overflow: hidden;
			-webkit-transition: all 300ms ease;
			transition: all 300ms ease;
			margin: 0 auto 20px;
			z-index: 2;
			border: 1px dashed #004183;
		}

		.mixCountry .country-block {
			position: relative;
			box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
		}

		.mixCountry .country-block .inner-box{
			padding: 0px  0px 20px;
		}
		.call-to-action .right-shape {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: auto;
    right: 0;
    max-width: 50.8%;
    background-color: var(--bg-theme-color3);
    -webkit-clip-path: polygon(20% 0, 100% 0%, 100% 100%, 10% 100%, 0 67%);
    clip-path: polygon(20% 0, 100% 0%, 100% 100%, 22% 100%, 0 48%);
}

.call-to-action .left-shape {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    max-width: 54.8%;
    background-color: var(--bg-theme-color3);
    background-image: url(../images/icons/map2.png);
    background-repeat: no-repeat;
    background-position: top left;
    -webkit-clip-path: polygon(84% 0, 100% 48%, 82% 100%, 0% 100%, 0% 0%);
    clip-path: polygon(75% 0, 100% 100%, 100% 100%, 0% 100%, 0% 0%);
}
	
.call-to-action .right-shape {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: auto;
    right: 0;
    max-width: 51.8%;
    background-color: var(--bg-theme-color3);
    -webkit-clip-path: polygon(20% 0, 100% 0%, 100% 100%, 10% 100%, 0 67%);
    clip-path: polygon(0% 0, 100% 0%, 100% 100%, 18% 100%, 0 32%);
}
</style>

<header class="main-header header-style-one">

<?php include 'inc/header.php';?>

</header>
	<!--End Main Header -->

	<!-- Start main-content -->
	<section class="page-title" style="background-image: url(images/background/page-title.jpg);">
		<div class="auto-container">
			<div class="title-outer">
				<h1 class="title">Collage and University</h1>
				<ul class="page-breadcrumb">
					<li><a href="index.php">Home</a></li>
					<!-- <li><a href="#">Pages</a></li> -->
					<li>Submit Application</li>
				</ul>
			</div>
		</div>
	</section>
	<!-- end main-content -->



 

    <!-- Training Section Three -->
	<section class="training-section-three application">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">Canada Institutions</span>
				<h2> <span class="color3">Canada </span> <br> Best Institutions</h2>
			</div>
			
			<div class="carousel-outer">
				<div class="training-carousel-two owl-carousel owl-theme">
					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/edumandate/canada/1.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Cypress College</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<img src="images/edumandate/canada/image1.jpg" class="img-influid" alt="">
									<a href="javascript:void(0);" class="read-more">
										<!-- <i class="fa fa-long-arrow-alt-right"></i> -->
										Submit Application
									</a>
									<h5 class="title pt-3"><a href="javascript:void(0);">Cypress College </a></h5>
									<div class="text">Cypress College is a public community college in Cypress, California.</div>
									
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/edumandate/canada/2.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Fraser Valley</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<img src="images/edumandate/canada/image2.jpg" class="img-influid" alt="">
									<a href="javascript:void(0);" class="read-more">
										<!-- <i class="fa fa-long-arrow-alt-right"></i> -->
										Submit Application
									</a>
									<h5 class="title pt-3"><a href="javascript:void(0);">University  Fraser Valley</a></h5>
									<div class="text">The University of the Fraser Valley, formerly known as University College of the Fraser Valley.</div>
									
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/edumandate/canada/3.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Vanier College</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<img src="images/edumandate/canada/image3.jpg" class="img-influid" alt="">
									<a href="javascript:void(0);" class="read-more">
										<!-- <i class="fa fa-long-arrow-alt-right"></i> -->
										Submit Application
									</a>
									<h5 class="title pt-3"><a href="javascript:void(0);">Vanier College </a></h5>
									<div class="text">Vanier College is an English-language public college located in the Saint-Laurent borough of Montreal, Quebec, Canada.</div>
									
								</div>
							</div>
						</div>
					</div>

					<!-- Training Block Two-->
					<div class="training-block-two">
						<div class="inner-box">
							<div class="image-box">
								<figure class="image"><img src="images/edumandate/canada/4.jpg" alt=""></figure>
								<a href="javascript:void(0);" class="read-more"><i class="fa fa-long-arrow-alt-right"></i></a>
								<h4 class="title">Acsenda</h4>
							</div>
							<div class="overlay-content">
								<div class="inner">
									<img src="images/edumandate/canada/image4.jpg" class="img-influid" alt="">
									<a href="javascript:void(0);" class="read-more">
										<!-- <i class="fa fa-long-arrow-alt-right"></i> -->
										Submit Application
									</a>
									<h5 class="title pt-3"><a href="javascript:void(0);">Acsenda </a></h5>
									<div class="text">The Acsenda School of Management – Vancouver, formerly known as Sprott Shaw Degree College, Canada </div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Training Section -->

	   <!-- Features Section -->
	   <section class="features-section pt-0" >
		<div class="auto-container">
				<div class="sec-title text-center">
				<span class="sub-title">UK Institutions</span>
				<h2> <span class="color3">UK </span> <br> Best University</h2>
			</div>
			<div class="row">
				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/1.png" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Apply for New Visa</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">University of sunderland</h6>
							</div>
							<div class="text">The University of Sunderland is a public research university located in Sunderland in the North East of England.</div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/2.png" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Immigration Program</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">University of West London</h6>
							</div>
							<div class="text">The University of West London is a public research university in the United Kingdom with campuses in Ealing, Brentford, and Reading, Berkshire.</div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/3.png" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Required Documents</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">University of Roehampton London</h6>
							</div>
							<div class="text">The University of Roehampton, London, formerly Roehampton Institute of Higher Education, is a public university in the United Kingdom</div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/4.jpg" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Apply for New Visa</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">Middlesex University</h6>
							</div>
							<div class="text">Middlesex University London is a public research university based in Hendon, northwest London, England. </div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/5.png" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Immigration Program</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">Regent College London</h6>
							</div>
							<div class="text">Navitas acknowledges the Traditional Owners of the lands in Australia and respects all First Nations peoples in the countries in which we operate.</div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Features Block Two -->
				<div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<figure class="image"><img src="images/edumandate/uk/6.jpg" alt=""></figure>
						<!-- <a href="#" class="theme-btn btn-style-one step">Required Documents</a> -->
						<div class="overlay-content">
							<div class="title-box">
								<i class="icon flaticon-immigration-1"></i>
								<h6 class="title">Navitas</h6>
							</div>
							<div class="text">Neque porro quisqum est qui dolorem ipsum quia dolor. tellus est aliquet egetristique nisullam.</div>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--Emd Features Section -->

	 <!-- Call to Action -->
	 <section class="call-to-action">
		<div class="left-shape"><img src="images/resource/plane.png" alt=""></div>
		<div class="right-shape" style="background-image: url(images/edumandate/gallery9.jpg)"></div>
		<div class="auto-container">
			<div class="row">
				<div class="title-column col-lg-6">
					<div class="inner-column">
						<div class="sec-title light">
							<h2>Ready to fly with <br>us your dream country</h2>
						</div>
						<ul class="list-style-two two-column">
							<li><i class="fa fa-check-circle"></i> Canada</li>
							<li><i class="fa fa-check-circle"></i> United Kingdom</li>
							<li><i class="fa fa-check-circle"></i> Europe</li>
							<li><i class="fa fa-check-circle"></i> Finland</li>
							<li><i class="fa fa-check-circle"></i> Denmark</li>
							<li><i class="fa fa-check-circle"></i> Greece</li>
						</ul>
						<!-- <a href="javascript:void(0);" class="theme-btn btn-style-four"><span class="btn-title">Book Consultation</span></a> -->

						<!-- <figure class="badge">
							<img src="images/resource/badge.png" alt="">
						</figure> -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Call to Action -->

	<!-- Team Section -->
	<section class="team-section">    
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">Europe Institutions</span>
				<h2>  <span class="color3">Europe  </span> <br> Institutions</h2>
			</div>

			<div class="row europe">
				<!-- Team block -->
				<div class="team-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/edumandate/Europe/6.png" alt=""></a></figure>
							<!-- <div class="social-links">
								<a href="#"><i class="fa fa-x"></i></a>
								<a href="#"><i class="fab fa-facebook"></i></a>
								<a href="#"><i class="fab fa-instagram"></i></a>
							</div> -->
						</div>
						<div class="info-box">
							<span class="designation">Eie European</span>
							<h4 class="name"><a href="javascript:void(0);">Business School</a></h4>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Team block -->
				<div class="team-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/edumandate/Europe/8.png" alt=""></a></figure>
							<!-- <div class="social-links">
								<a href="#"><i class="fa fa-x"></i></a>
								<a href="#"><i class="fab fa-facebook"></i></a>
								<a href="#"><i class="fab fa-instagram"></i></a>
							</div> -->
						</div>
						<div class="info-box">
							<span class="designation">Study world global </span>
							<h4 class="name"><a href="javascript:void(0);">College Malta</a></h4>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>

				<!-- Team block -->
				<div class="team-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/edumandate/Europe/3.png" alt=""></a></figure>
							<!-- <div class="social-links">
								<a href="#"><i class="fa fa-x"></i></a>
								<a href="#"><i class="fab fa-facebook"></i></a>
								<a href="#"><i class="fab fa-instagram"></i></a>
							</div> -->
						</div>
						<div class="info-box">
							<span class="designation">Arden</span>
							<h4 class="name"><a href="javascript:void(0);">University Berlin</a></h4>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Submit Application</a>
						</div>
					</div>
				</div>
				<!-- Team block -->
				<div class="team-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><a href="javascript:void(0);"><img src="images/edumandate/Europe/5.png" alt=""></a></figure>
							<!-- <div class="social-links">
								<a href="#"><i class="fa fa-x"></i></a>
								<a href="#"><i class="fab fa-facebook"></i></a>
								<a href="#"><i class="fab fa-instagram"></i></a>
							</div> -->
						</div>
						<div class="info-box">
							<span class="designation">Arden</span>
							<h4 class="name"><a href="javascript:void(0);">Berlin School of </a></h4>
							<a href="javascript:void(0);" class="theme-btn btn-style-three read-more">Buniness & nnovation</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Team Section -->


		<!-- Countries Section -->
	<section class="countries-section pt-0">
		<div class="auto-container">
			<div class="sec-title text-center">
				<span class="sub-title">Finland & Denmark</span>
				<h2>  <span class="color3">Finland & Denmark</span><br>  Institutions</h2>
			</div>
	
			<div class="carousel-outer mixCountry">
				<!-- Countries Carousel -->
				<div class="countries-carousel owl-carousel owl-theme">
					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/Finland/1.png" alt=""></div>
							
							<a href="javascript:void(0);" class="theme-btn">Finland</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/Finland/2.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Finland</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/Finland/3.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Finland</a>
						</div>
					</div>

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/Finland/4.png" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Finland</a>
						</div>                        
					</div>

					<!-- Country Block-->
					<!-- <div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/demark/1.jpeg" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">England</a>
						</div>                        
					</div> -->

					<!-- Country Block-->
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/demark/2.jpg" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Demark</a>
						</div>
					</div>
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/demark/3.jpg" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Demark</a>
						</div>
					</div>
					<div class="country-block">
						<div class="inner-box">
							<div class="flag"><img src="images/edumandate/demark/4.jpg" alt=""></div>
							<a href="javascript:void(0);" class="theme-btn">Demark</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--End Countries Section Two -->


   




    <?php include 'inc/footer.php';?>