
		<!-- Header Top -->
		<!-- <div class="header-top">
			<div class="inner-container">

				<div class="top-left">
					
					<ul class="list-style-one">
						<li><i class="fa fa-envelope"></i> <a href="https://html.kodesolution.com/cdn-cgi/l/email-protection#85ebe0e0e1ede0e9f5c5e6eae8f5e4ebfcabe6eae8"><span class="__cf_email__" data-cfemail="26484343424e434a566645494b5647485f0845494b">[email&#160;protected]</span></a></li>
						<li><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li> 
						<li><i class="fa fa-clock"></i> Mon _ Sat: 9.00 to 18.00</li> 
					</ul>
				</div>
				
				<div class="top-right">
					<ul class="social-icon-one">
						<li><a href="javascript:void(0);"><span class="fa fa-x"></span></a></li>
						<li><a href="javascript:void(0);"><span class="fab fa-facebook-f"></span></a></li>
						<li><a href="javascript:void(0);"><span class="fab fa-pinterest-p"></span></a></li>
						<li><a href="javascript:void(0);"><span class="fab fa-instagram"></span></a></li>
					</ul>
				</div>
			</div>
		</div> -->
		<!-- Header Top -->

		<!-- Header Lower -->
		<div class="header-lower">
			<!-- Main box -->
			<div class="main-box">
				<div class="logo-box">
					<div class="logo">
                        <a href="index.php">
                        <img src="images/edumandate/logo_new_edu.svg" width="100%" alt="" title="">
                        </a>
                    </div>
				</div>

				<!--Nav Box-->
				<div class="nav-outer">
					
					<nav class="nav main-menu">
						<ul class="navigation">
							<li class="current dropdown"><a href="javascript:void(0);">Study Destination</a>
								<ul>
									<li><a href="javascript:void(0);">United Kingdom</a></li>
									<li><a href="javascript:void(0);">Canada</a></li>
									
									
								</ul>
							</li>
							<li class="dropdown"><a href="#">Service</a>
								<ul>
									<li><a href="javascript:void(0);">Partners</a></li>
									<li><a href="javascript:void(0);">Institutions</a></li>
									<li><a href="javascript:void(0);">Germany Block Acct.</a></li>
								</ul>
							</li>
							<li class="dropdown"><a href="#">Company</a>
								<ul>
									<li><a href="javascript:void(0);">AboutUs</a></li>
									<li><a href="javascript:void(0);">Team</a></li>
									<li><a href="javascript:void(0);">Career</a></li>
									<li><a href="javascript:void(0);">Blog</a></li>
								</ul>
							</li>
							
							<li><a href="javascript:void(0);">Collaboration</a></li>
                            <li><a href="application.php">Application</a></li>
                            <li><a href="javascript:void(0);">ContactUs</a></li>
						</ul>
					</nav>
					<!-- Main Menu End-->

					<div class="outer-box">                        
						<a href="tel:+92(8800)9806" class="info-btn">
							<img class="icon" src="images/icons/icon-phone.png" alt="">
							<small class="title">Call Anytime</small> 
							<strong class="text">+ 92 ( 8800 ) 86300</strong>
						</a>

						

						<a href="javascript:void(0);" class="theme-btn btn-style-one"><span class="btn-title">Book Consultation</span></a>

						<!-- Mobile Nav toggler -->
						<div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Header Lower -->

		<!-- Mobile Menu  -->
		<div class="mobile-menu">
			<div class="menu-backdrop"></div>
		
			<!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
			<nav class="menu-box">
				<div class="upper-box">
					<div class="nav-logo"><a href="javascript:void(0);"><img src="images/edumandate/logo_new_edu.svg" alt="" title=""></a></div>
					<div class="close-btn"><i class="icon fa fa-times"></i></div>
				</div>
		
				<ul class="navigation clearfix">
					<!--Keep This Empty / Menu will come through Javascript-->
				</ul>
				<ul class="contact-list-one">
					<li>
						<!-- Contact Info Box -->
						<div class="contact-info-box">
							<i class="icon lnr-icon-phone-handset"></i>
							<span class="title">Call Now</span>
							<a href="tel:+92880098670">+92 88009 86704</a>
						</div>
					</li>
					<li>
						<!-- Contact Info Box -->
						<div class="contact-info-box">
							<span class="icon lnr-icon-envelope1"></span>
							<span class="title">Send Email</span>
							<a href="mailto:info@edumandate.com">info@edumandate.com</a>
						</div>
					</li>
					<li>
						<!-- Contact Info Box -->
						<div class="contact-info-box">
							<span class="icon fa fa-map-marker"></span>
							<span class="title">Office</span>
							717, 7th Floor, Vishal Tower 10, District Centre, Janak Puri, New Delhi, West, Pin: 110058
						</div>
					</li>
				</ul>
		
		
				<ul class="social-links">
					<li><a href="javascript:void(0);"><i class="fa fa-x"></i></a></li>
					<li><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
					<li><a href="javascript:void(0);"><i class="fab fa-pinterest"></i></a></li>
					<li><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</nav>
		</div><!-- End Mobile Menu -->

		<!-- Header Search -->
		<!-- <div class="search-popup">
			<span class="search-back-drop"></span>
			<button class="close-search"><span class="fa fa-times"></span></button>
		
			<div class="search-inner">
				<form method="post" action="https://html.kodesolution.com/2023/immigro-html/javascript:void(0);">
					<div class="form-group">
						<input type="search" name="search-field" value="" placeholder="Search..." required="">
						<button type="submit"><i class="fa fa-search"></i></button>
					</div>
				</form>
			</div>
		</div> -->
		<!-- End Header Search -->

		<!-- Sticky Header  -->
		<div class="sticky-header">
			<div class="auto-container">
				<div class="inner-container">
					<!--Logo-->
					<div class="logo">
						<a href="javascript:void(0);" title=""><img src="images/edumandate/logo_new_edu.svg" width="100%" alt="" title=""></a>
					</div>
		
					<!--Right Col-->
					<div class="nav-outer">
						<!-- Main Menu -->
						<nav class="main-menu">
							<div class="navbar-collapse show collapse clearfix">
								<ul class="navigation clearfix">
									<!--Keep This Empty / Menu will come through Javascript-->
								</ul>
							</div>
						</nav><!-- Main Menu End-->
		
						<!--Mobile Navigation Toggler-->
						<div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
					</div>
				</div>
			</div>
		</div><!-- End Sticky Menu -->
