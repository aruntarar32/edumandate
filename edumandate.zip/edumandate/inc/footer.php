<style>
	.footer-bottom {
    position: relative;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    background-color: #e3000f;
}
.footer-bottom .copyright-text {
    position: relative;
    font-size: 15px;
    line-height: 25px;
    color: #fff;
}

.legalmenu{
	display: flex;
	justify-content: space-between;
}
.legalmenu a{
	color: #fff;
	
}

.ftinfo {
    font-size: 15px;
    color: #7b87a1;
    line-height: 24px;
    font-weight: 500;
    margin-bottom: 20px;
	margin-right:10px;
}
</style>
	<!-- Main Footer -->
	<footer class="main-footer">
		<div class="bg bg-pattern-7"></div>
		<!-- <div class="auto-container">
			<div class="footer-upper">
				<div class="logo-box"><img src="images/logo-2.png" alt=""></div>
				<ul class="contact-info">
					<li>
						<i class="icon fa fa-phone-square"></i>
						<span class="title">Phone:</span>
						<div class="text"><a href="tel:+9288006830">+92 (8800) 6830</a></div>
					</li>
					<li>
						<i class="icon fa fa-envelope"></i>
						<span class="title">Email:</span>
						<div class="text"><a href="https://html.kodesolution.com/cdn-cgi/l/email-protection#adc8d7c4ccdfc2edcec2c0ddccc3d483cec2c0"><span class="__cf_email__" data-cfemail="0f6a75666e7d604f6c60627f6e6176216c6062">[email&#160;protected]</span></a></div>
					</li>
					<li>
						<i class="icon fa fa-map-marker"></i>
						<span class="title">Address:</span>
						<div class="text">30 Broklyn Street. USA</div>
					</li>
				</ul>
				<div class="btn-box">
					<a href="javascript:void(0);" class="theme-btn btn-style-four"><span class="btn-title">Book Consultation</span></a>
				</div>
			</div>
		</div> -->
	
		<!--Widgets Section-->
		<div class="widgets-section">
			<div class="auto-container">
				<div class="row">
					<!--Footer Column-->
					<div class="footer-column col-xl-6 col-lg-8 col-md-12 mb-0">
						<div class="row">

							<div class="footer-widget col-lg-6 col-md-6 col-ms-12 bg-white">
								<h6 class="widget-title">Company</h6>
								<img src="images/edumandate/logo_new_edu.svg" width="100%" alt="" title="">
								<p class="pt-3">Connecting Canadian, UK, and European Institutions with Top Agents in Asia and Africa.</p>
							</div>

							<div class="footer-widget col-lg-6 col-md-6 col-ms-12">
								<div class="d-flex justify-content-center">
									<div>
										<h6 class="widget-title">Links</h6>
										<ul class="user-links">
											<li><a href="javascript:void(0);">About</a></li>
											<li><a href="javascript:void(0);">Meet Team</a></li>
											<li><a href="javascript:void(0);">Blog</a></li>
											<li><a href="javascript:void(0);">Career</a></li>
											<li><a href="javascript:void(0);">Contact</a></li>

										</ul>
									</div>
								</div>
								
							</div>

							

						
						</div>
					</div>

					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-8">
						<div class="footer-widget gallery-widget">
						<h6 class="widget-title">Study Degination</h6>
								<ul class="user-links">
									<li><a href="javascript:void(0);">Canada</a></li>
									<li><a href="javascript:void(0);">United Kingdom </a></li>
									<li><a href="javascript:void(0);">Europe</a></li>
									<li><a href="javascript:void(0);">Finland</a></li>
									<li><a href="javascript:void(0);">Denmark</a></li>
								</ul>
						</div>
					</div>

					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-12 col-md-6 mb-0">
						<div class="footer-widget">
							<h6 class="widget-title">Operations Office:</h6>
							<div class="subscribe-form">
								<div class="text">717, 7th Floor, Vishal Tower 10, District Centre, Janak Puri, New Delhi, West, Pin: 110058 </div>
								
							</div>
							<div class="contact-info-box">
								<i class="icon lnr-icon-phone-handset"></i>
								<span class="title"> Call Now </span>
								<a href="tel:+92880098670" class="ftinfo"> +92 88009 86704 </a>
							</div>
							<div class="contact-info-box">
								<span class="icon lnr-icon-envelope1"></span>
								<span class="title"> Send Email </span>
								<a href="mailto:info@edumandate.com" class="ftinfo">: info@edumandate.com </a>
							</div>
							<ul class="social-icon-two mt-3">
								<li><a href="javascript:void(0);"><i class="fab fa-linkedin"></i></a></li>
								<li><a href="javascript:void(0);"><i class="fab fa-facebook"></i></a></li>
								<li><a href="javascript:void(0);"><i class="fab fa-pinterest"></i></a></li>
								<li><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
								<li><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>

							</ul>
							
						</div>
					</div>

					<div class="footer-column col-xl-12 col-lg-12 col-md-6 mb-0">
						<div class="footer-widget pt-0 ">
						
							<div class="legalmenu">
								
								<div><a href="javascript:void(0);">Partners</a></div>
								<div><a href="javascript:void(0);">Institutions</a></div>
								<div><a href="javascript:void(0);">Germany Block Acct.</a></div>
								<div><a href="javascript:void(0);">Submit Application</a></div>
								<li><a  href="javascript:void(0);">Collaboration</a></li>
								<li><a href="javascript:void(0);">FAQ</a></li>
							</div>
							

							
							
						</div>
					</div>
				</div>
			</div>
		</div>
	
		<!--Footer Bottom-->
		<div class="footer-bottom">
			<div class="auto-container">
				<div class="inner-container">
					<div class="copyright-text">Copyright &copy; All Right Reserved | Powered by <a href="javascript:void(0);">edumandate</a>
				</div>
			</div>
		</div>
	</footer>
	<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>
</body>


</html>